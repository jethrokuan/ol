(function() {

  jQuery(function() {
    return $("a[rel=popover]").popover();
  });

}).call(this);
